
library(ggplot2)
theme_set(theme_classic())

## ----firstmodel_stan_code, tidy = TRUE, comment="", echo=FALSE-----------
cat(readLines("firstmodel.stan"), sep = "\n")  

## ---- message=F, warning=F-----------------------------------------------
library(rstan)
# Save compiled models:
rstan_options(auto_write = TRUE)
# Parallelize the chains using all the cores:
options(mc.cores = parallel::detectCores())  
# options(mc.cores = parallel::detectCores() - 1) # If you want to have an extra core free

# Create a list:
qresp_data <-  list(c = 46, 
                    N = 100)
# Fit the model with the default values of number of chains and iterations
# chains = 4,    iter = 2000
fit <- stan(file = 'firstmodel.stan', data = qresp_data)  

## ------------------------------------------------------------------------
print(fit, pars=c("theta"))

## ---- fig.height=2-------------------------------------------------------
traceplot(fit, pars=c("theta"))

## ---- reading_noreading--------------------------------------------------
noreading_data <- read.table(header = F,"data/1.dat",encoding="latin1")
noreading_data <- noreading_data[c("V2","V3","V5","V6","V8")]
colnames(noreading_data) <- c("type","item","wordn","word","RT")
tail(noreading_data)
summary(noreading_data$RT)
class(noreading_data)

## ---- noreading_list-----------------------------------------------------
# We save the RTs of each row, and also the total number of observations N.

noreading_list <-  list(Y = noreading_data$RT, 
                    N = length(noreading_data$RT))

## ----no_reading_1_stan_code, tidy = TRUE, comment="", echo=FALSE---------
cat(readLines("noreading_1.stan"), sep = "\n") 

## ---- fake_data----------------------------------------------------------
set.seed(123)
N <- 500
true_mu <- 400
true_sigma <- 125
RT <- rnorm(N, true_mu, true_sigma)

RT <- round(RT) 
fake_list <- list(Y=RT,N=N)


## ----fit_fake, message=FALSE, warning=FALSE, results="hide"--------------
fit_fake <- stan(file = 'noreading_1.stan',  data = fake_list)            


## ----traceplot_fit_fake, fig.height=2------------------------------------
traceplot(fit_fake)


## ------------------------------------------------------------------------
print(fit_fake, probs =c(.025,.5,.975), pars=c("mu","sigma"))

## ---- message=FALSE, warning=FALSE, results="hide"-----------------------
fit_noreading <- stan(file = 'noreading_1.stan', 
    data = noreading_list)            

## ------------------------------------------------------------------------

print(fit_noreading, probs =c(.025,.5,.975), pars=c("mu","sigma"))


## ---- fig.height=2-------------------------------------------------------
traceplot(fit_noreading)

## ----noreading_plot, fig.height=2, message=F-----------------------------
library(bayesplot)
# We need to first extract the chains:
post_noreading <- as.array(fit_noreading)
dimnames(post_noreading)
# And then we can plot them:
mcmc_hist(post_noreading, pars = c("mu", "sigma"))

## ---- message=FALSE, warning=FALSE, tidy=F-------------------------------

mu_samples <- post_noreading[, , "mu"] 
# Another possibility would be
# mu_samples <- rstan::extract(fit_noreading)$mu

# Proportion of samples over 170
mean(mu_samples > 170)


## ---- message=FALSE, warning=FALSE---------------------------------------
print(fit_noreading, probs =c((1.00-.73)/2, (1.00+.73)/2), pars=c("mu"))

## ----no_reading_2_stan_code, tidy = TRUE, comment="", echo=FALSE---------
cat(readLines("noreading_2.stan"), sep = "\n")

## ---- message=FALSE, warning=FALSE, results="hide"-----------------------
fit_noreading_2 <- stan(file = 'noreading_2.stan', 
    data = noreading_list)            

## ------------------------------------------------------------------------

print(fit_noreading_2, probs =c(.025,.5,.975), pars=c("mu","sigma"))


## ---- fig.height=2-------------------------------------------------------
traceplot(fit_noreading_2)

## ----fit_noreading_2plot, fig.height=2, message=F------------------------
post_noreading_2 <- as.array(fit_noreading_2)
mcmc_hist(post_noreading_2, pars = c("mu", "sigma"))


## ---- reading_noreading_sb-----------------------------------------------
# We create the new column in the data frame
noreading_data$presses <- 1:nrow(noreading_data)
# We center the column
noreading_data$c_presses <- noreading_data$presses - mean(noreading_data$presses)
# We add it to the list that goes into rstan
noreading_list$presses <-  noreading_data$c_presses

## ----no_reading_3_stan_code, tidy = TRUE, comment="", echo=FALSE---------
cat(readLines("noreading_3.stan"), sep = "\n")

## ---- message=FALSE, warning=FALSE, results="hide"-----------------------
fit_noreading_3 <- stan(file = 'noreading_3.stan', 
    data = noreading_list)            

## ------------------------------------------------------------------------

print(fit_noreading_3, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma"))


## ---- fig.height=2-------------------------------------------------------
traceplot(fit_noreading_3)

## ----fit_noreading_3plot, fig.height=2, message=F------------------------
post_noreading_3 <- as.array(fit_noreading_3)
mcmc_hist(post_noreading_3, pars=c("alpha","beta","sigma"))


## ---- echo=F, results="hide"---------------------------------------------
beta_mean <- round(summary(fit_noreading_3)$summary["beta","mean"],2)
beta_high <- round(summary(fit_noreading_3)$summary["beta","97.5%"],2)
beta_low <- round(summary(fit_noreading_3)$summary["beta","2.5%"],2)

## ----beta_samples--------------------------------------------------------

beta_samples <- post_noreading_3[, , "beta"] 

mean(beta_samples > 0)


## ----no_reading_4_stan_code, tidy = TRUE, comment="", echo=FALSE, warning=F----
cat(readLines("noreading_4.stan"), sep = "\n")  

## ---- message=FALSE, warning=FALSE, results="hide"-----------------------
fit_noreading_4 <- stan(file = 'noreading_4.stan', 
    data = noreading_list)            


## ---- eval=F-------------------------------------------------------------
## traceplot(fit_noreading_4, pars=c("alpha","beta","sigma"))
## print(fit_noreading_4, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma"))

## ---- message=FALSE, warning=FALSE, tidy=F-------------------------------
matrix_pred_Y <- rstan::extract(fit_noreading_4)$pred_Y
dim(matrix_pred_Y)
# first dimension: number of samples = 2000 iterations per chain /2 * 4 chains
# second dimension: number of original datapoints

## ---- message=FALSE, warning=FALSE, tidy=F-------------------------------
alpha_samples <- rstan::extract(fit_noreading_4)$alpha
beta_samples <- rstan::extract(fit_noreading_4)$beta
sigma_samples <- rstan::extract(fit_noreading_4)$sigma
rt_gen <- c()
for(i in 1:noreading_list$N) {
  mu <- alpha_samples[1] + beta_samples[1] * noreading_list$presses[i]
  sigma<- sigma_samples[1]
  rt_gen[i] <- rnorm(1, mu , sigma )  
}

length(rt_gen)
head(rt_gen)

## ---- message=FALSE, warning=FALSE,fig.height=4--------------------------
# Let's pick 11 random simulations over the 4000 that we have
pick <- sample(1:4000,11)
ppc_hist(noreading_list$Y, matrix_pred_Y[pick, ]) 

## ----lognormal, fig.height=2,fig.width=3.5, fig.show='hold', message=F, warning=F----
mu <- 6
sigma <- 0.5
N <- 100000
# We generate N random samples from a log-normal distribution.
sl <- rlnorm(N, mu, sigma)
lognormal_plot <- ggplot(data.frame(samples=sl), aes(sl)) + geom_histogram() + 
      ggtitle("Log-normal distribution\n") + ylim(0,25000) + xlim(0,2000)
# We generate N random samples from a normal distribution, and then we exponentiate them
sn <- exp(rnorm(N, mu, sigma))
normalplot <- ggplot(data.frame(samples=sn), aes(sn)) + geom_histogram() + 
      ggtitle("Exponentiated samples of\na normal distribution") + ylim(0,25000) + xlim(0,2000)

plot(lognormal_plot)
plot(normalplot)

## ---- echo=F-------------------------------------------------------------

ms_diff <- function(Intercept){
  exp(Intercept + .1) - exp(Intercept)
}
df <- tibble::data_frame(Intercept=seq(.1,15,.01), ms= ms_diff(Intercept))
ggplot(df, aes(x=Intercept,y=ms)) + geom_point() + scale_y_continuous("Difference in milliseconds")


## ----no_reading_log_stan_code, tidy = TRUE, comment="", echo=FALSE, warning=F----
cat(readLines("noreading_log.stan"), sep = "\n")   

## ---- message=FALSE, warning=FALSE, results="hide"-----------------------
fit_noreading_log <- stan(file = 'noreading_log.stan', 
    data = noreading_list)      

## ---- fig.height=2-------------------------------------------------------
traceplot(fit_noreading_log, pars =c("alpha","beta","sigma"))
print(fit_noreading_log, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma", "RT_under", "effect_of_1_press"))
# We'll need more digits to see what's going on with beta
print(fit_noreading_log, probs =c(.025,.5,.975), pars=c("beta"),digits=5)

## ---- echo=F, results="hide"---------------------------------------------
options(scipen=999, digits=5)

beta_mean <- round(summary(fit_noreading_log)$summary["beta","mean"],4)
beta_high <- round(summary(fit_noreading_log)$summary["beta","97.5%"],4)
beta_low <- round(summary(fit_noreading_log)$summary["beta","2.5%"],4)
 
post_noreading_log <- as.array(fit_noreading_log)
beta_samples <- post_noreading_log[, , "beta"] 


## ---- echo=F, results="hide"---------------------------------------------

beta_mean <- round(summary(fit_noreading_log)$summary["beta","mean"],4)
beta_high <- round(summary(fit_noreading_log)$summary["beta","97.5%"],4)
beta_low <- round(summary(fit_noreading_log)$summary["beta","2.5%"],4)

post_noreading_log <- as.array(fit_noreading_log)
beta_samples <- post_noreading_log[, , "beta"] 


## ---- echo=F, results="hide"---------------------------------------------

effect_of_1_press_mean <- round(summary(fit_noreading_log)$summary["effect_of_1_press","mean"],2)
effect_of_1_press_high <- round(summary(fit_noreading_log)$summary["effect_of_1_press","97.5%"],2)
effect_of_1_press_low <- round(summary(fit_noreading_log)$summary["effect_of_1_press","2.5%"],2)

options(scipen=999, digits=3)


## ---- message=FALSE, warning=FALSE, fig.height=4-------------------------


matrix_pred_Y_log <- rstan::extract(fit_noreading_log)$pred_Y
dim(matrix_pred_Y_log)


# Let's pick 11 random simulations over the 4000
pick <- sample(1:4000,11)
ppc_hist(noreading_list$Y, matrix_pred_Y_log[pick, ]) 

## ---- message=FALSE, warning=FALSE, fig.height=2,fig.width=3.5,fig.show='hold', tidy=F----
normalsum <- ppc_stat(noreading_list$Y, matrix_pred_Y, stat = "max") + 
             ggtitle("Normal model")
lognormalsum <- ppc_stat(noreading_list$Y, matrix_pred_Y_log, stat = "max") + 
                ggtitle("Log-normal model")
plot(normalsum)
plot(lognormalsum)

