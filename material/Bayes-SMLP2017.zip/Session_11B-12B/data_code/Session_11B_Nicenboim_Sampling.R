library(ggplot2)
theme_set(theme_classic()) 

## ---- fake_data----------------------------------------------------------
set.seed(123)  # To always get  the same random numbers
N <- 500
true_mu <- 400
true_sigma <- 125
RT <- rnorm(N, true_mu, true_sigma)
# I'm rounding the RT, since it's never the case that we have more than 1 ms of precision in our measurements
RT <- round(RT) 

## ---- rts----------------------------------------------------------------
RT

## ---- loglikelihood------------------------------------------------------
# The loglikelihood is a function of the value of parameters inside the vector
#  theta (i.e., mu and sigma) given the whole data
loglikelihood <- function(theta, Y){
  #  `theta` is a vector of the parameters, in this case mu and sigma;
  #  `Y` is a vector containing all the observations, in this case we'll use the RTs
    mu <- theta[1]
    sigma <- theta[2]
    if (sigma > 0) {
       # dnorm gives us the density at each point of the data,
       # log = TRUE to have it log-scaled.
      singlelikelihoods <- dnorm(Y, mean = mu, sd = sigma, log = TRUE)
    } else  {
      # This is just a hack to prevent values of sigma lower than 0, there are more principled ways to achieve this.                     
      singlelikelihoods <- dnorm(Y, mean = mu, sd = 0, log = TRUE)
    }
    # To get the likelihood we multiply the probability density of each value of Y, or we sum them in log-scale:
    # log(A * B) = log(A) + log(B)
    sumll = sum(singlelikelihoods)
    return(sumll)   
}

## ------------------------------------------------------------------------
# recall that the true values were  400 and 125
loglikelihood(theta=c(350,100),Y=RT)
loglikelihood(theta=c(1000,10),Y=RT)

## ---- visLoglik, echo = FALSE,fig.cap='Likelihood of the parameters given the data. The triangle indicates the true values. See the Appendix for the code.\\label{fig:visLoglik}'----
library(ggplot2)
library(scales) 

# These are the likelihoods for the different mu that we are going to show. 
# A good (or decent) model shouldn't give any likelihood to values of mu < 0 because reaction times can't be negative.
mus <- seq(-1000,1000,1)
sigmas <- seq(1,250,1)

# Data frame with the combination:
possible_thetas <- data.frame(mu = rep(mus, each = length(sigmas)), 
                            sigma = rep(sigmas, times =length(mus)))

# I apply the likelihood(realdata, poss_values) over the rows (MARGIN=1) of 
#  possible_thetas[c("mu", "sigma")], see ?apply.
# The following  line takes some time:
possible_thetas$loglik <- apply(possible_thetas[c("mu", "sigma")], 1, 
                    function(poss_values) {
                      return(loglikelihood(theta=poss_values, Y=RT))
                      })

#Notice that the log(likelihoods) can be quite large in absolute value (very
#negative!), this would have produced an underflow on the raw scale because they correspond to
#values extremely close to zero.
q <- quantile(possible_thetas$loglik,c(0,.01,.0275,.2,.5,.8,.975,.99,1))

# We are going to use the quantiles to rescale the colors:
vis_lik <- ggplot(possible_thetas, aes(x=mu,y=sigma,fill=loglik,z=loglik)) 
 # This is the color map:
vis_lik <- vis_lik + 
    geom_raster() + 
    stat_contour(breaks=q) 

    # We need to rescale the colors and the lines, 
    #because there are too many extreme values of loglik:
vis_lik <- vis_lik +  
    scale_fill_gradientn(colours = terrain.colors(9),
      values = rescale(q),breaks=q,labels=round(q),guide="legend") +
     geom_point(x=true_mu,y=true_sigma,alpha=1,color="red",shape=2,inherit.aes = F)


plot(vis_lik)

## ---- visLoglikZoomed, echo = FALSE,fig.cap='A closer look to the most likely parameters according to likelihood. The triangle indicates the true values. See the Appendix for the code.\\label{fig:visLoglikZoomed}'----


mus <- seq(380, 430,1)
sigmas <- seq(100, 140,1)

possible_thetas <- data.frame(mu = rep(mus, each = length(sigmas)), 
                            sigma = rep(sigmas, times =length(mus)))

possible_thetas$loglik <- apply(possible_thetas[c("mu", "sigma")], 1, 
                    function(poss_values) {
                      return(loglikelihood(theta=poss_values, Y=RT))
                      })


vis_lik_zoomed <- 
ggplot(possible_thetas, aes(x=mu,y=sigma,fill=loglik,z=loglik)) + 
    geom_raster() + 
    stat_contour() +  scale_fill_gradientn(colours = terrain.colors(9))+
     geom_point(x=true_mu,y=true_sigma,alpha=1,color="red",shape=2)+ xlim(380, 430) + ylim(100, 140)

  

plot(vis_lik_zoomed)



## ---- logpriors----------------------------------------------------------
#We also do this in log-scale
mu_prior <- function(mu) {
  density <- dnorm(mu, mean = 0, sd = 2000, log = T)
  return(density)
}
sigma_prior <- function(sigma) { 
  #density of a normal distribution truncated at 0
  density <- ifelse(sigma>0, dnorm(sigma, mean =  0, sd = 500, log = T) * 2,
                              log(0))
  return(density)
}

## ---- logposterior-------------------------------------------------------
logposterior <- function(Y, theta){
  unnormalized_density <- loglikelihood(theta=theta, Y=Y) + mu_prior(mu=theta[1]) + 
  sigma_prior(sigma=theta[2])
    return (unnormalized_density)
}

## ------------------------------------------------------------------------
#mu = 4, and sigma = 1
start_values <- c(4,1) 

## ----proposal_function---------------------------------------------------
proposal_function <- function(theta, proposal_width=1){
    # Number of parameters:
    num_par <- length(theta)
    # Here we jump the same for both parameters:
    # rep(proposal_width,num_par) means that we are assuming the same width for both parameters
    proposal <- rnorm(num_par, mean = theta, sd= rep(proposal_width,num_par))
    # Notice that we are producing a vector with "num_par" values, in our case 2. That's why mean and sd will include two values each.
    return(proposal)
}

# See what happens when we feed the start_values to the proposal function:
start_values
proposal_function(theta=start_values)


## ---- next_value,warning=T-----------------------------------------------
next_value <- function(Y, proposal, current){
    # Remember that dividing is the difference in log scale:
    p_accept <- exp(logposterior(Y=Y, theta=proposal) - logposterior(Y=Y, theta=current))
    # p_accept will only act as a probability if < 1, 
    # if >1, it will just say "jump"
    if (runif(1) < p_accept){ 
        return(proposal)
    } else {
        return(current)
    }
    # The previous if else is the same as doing this:
    # if (p_accept >= 1){ 
    #     return(proposal)
    # else {
    #     toss_a_coin <- rbinom(1,1,p_accept)
    #     if(toss_a_coin==1){
    #         return(proposal)
    #     } else {
    #        return(current)
    #     }
    # }
}

# Let's see an example of its use. Would we jump from the start values to c(200,100)?
next_value(Y=RT, proposal=c(200,100), current = start_values )

# Yes, if we want to understand why, we could look at the output of p_accept:
(p_accept <- exp(logposterior(Y=RT, theta=c(200,100)) - logposterior(Y=RT, theta=start_values)))

# This is much bigger than 1! That means that the acceptance ratio is 1, we would always jump.

# In the following case,the proposed place (mu=279, sigma=100) is worse than the current place (mu=280, sigma=100). That means that we would jump with the following probability (acceptance ratio):
(p_accept <- exp(logposterior(Y=RT, theta=c(279,100)) - logposterior(Y=RT, theta=c(280,100))))

## ---- run_metropolis_MCMC------------------------------------------------
run_metropolis_MCMC <- function(Y, start_values, iterations){
    #We reserve the space for a chain for each parameter:
    chain <- array(dim = c(iterations,2))
    # This is the current state of the chain:
    current_state <- start_values
    for (i in 1:iterations){
        # I'm being a bit redundant here for the sake of clarity:
        proposal <- proposal_function(current_state)
        chain[i,] <- next_value(Y, proposal, current_state)
        # The current state is now:
        current_state <- chain[i,]
    }
    return(chain)
}
#We run it here:
iterations <-  500
chains <- run_metropolis_MCMC(RT, start_values, iterations)
# Notice the dimensions of the chains: 
# number of iterations * parameters:
dim(chains)

## ---- end_results--------------------------------------------------------
# Data frame with the chains
chains_run_1 <- data.frame(theta = 
                            c(rep("mu",iterations),rep("sigma",iterations)),
                            value = 
                            c(chains[,1],chains[,2]), iter=rep(1:iterations,2))

head(chains_run_1)

# This graph is usually called trace plot:
trace_plot <- ggplot(chains_run_1,aes(x=iter,y=value)) +
             facet_grid(theta~., scales="free")+ geom_point(size=.1) 
print(trace_plot)

## ---- more_chains, tidy=F------------------------------------------------
# We'll run a couple of chains so will need to identify them:
chains_run_1$id <- 1
chains_2 <- run_metropolis_MCMC(RT, start_values, iterations)
chains_run_2 <- data.frame(theta = 
                            c(rep("mu",iterations),rep("sigma",iterations)),
                            value = 
                            c(chains_2[,1],chains_2[,2]), iter=rep(1:iterations,2))
chains_run_2$id <- 2
chains_runs <- rbind(chains_run_1, chains_run_2)
trace_plot  <- ggplot(chains_runs,aes(x=iter,y=value, color=factor(id)))+
      facet_grid(theta~., scales="free")+ geom_point(size=.1) + scale_color_manual(values=c("black","red"))
print(trace_plot)

# We'll add a third group of chains with different starting values that makes
#  the non-convergence even more obvious:
chains_3 <- run_metropolis_MCMC(RT, c(500,500), iterations)
chains_run_3 <- data.frame(theta = 
                            c(rep("mu",iterations),rep("sigma",iterations)),
                            value = 
                            c(chains_3[,1],chains_3[,2]), iter=rep(1:iterations,2))

chains_run_3$id <- 3
chains_runs <- rbind(chains_runs, chains_run_3)
trace_plot <- ggplot(chains_runs,aes(x=iter,y=value, color=factor(id))) + 
        facet_grid(theta~., scales="free") + geom_point(size=.1) + scale_color_manual(values=c("black","red","blue"))
# Plot:
print(trace_plot)

## ---- longer_chains------------------------------------------------------
iterations <- 10000
chains_1 <- run_metropolis_MCMC(RT, start_values, iterations)
chains_2 <- run_metropolis_MCMC(RT, start_values, iterations)
chains_3 <- run_metropolis_MCMC(RT, c(500,500), iterations)

# Columns to build a dataframe with the chains
theta = c(rep("mu",iterations*3),rep("sigma",iterations*3))
value = c(chains_1[,1],chains_2[,1],chains_3[,1], chains_1[,2],chains_2[,2],chains_3[,2])
iter=rep(1:iterations,2*3)
id=rep(1:3,each=iterations, times=2)

longer_chains_runs <- data.frame(
theta=theta,value=value,iter=iter,id=id)

head(longer_chains_runs)
trace_plot<- ggplot(longer_chains_runs,aes(x=iter,y=value, color=factor(id)))+ facet_grid(theta~., scales="free")+ geom_point(size=.1)
print(trace_plot)

## ----hairy_trace_plot----------------------------------------------------
hairy_trace_plot<- ggplot(subset(longer_chains_runs,iter >3000),aes(x=iter,y=value, color=factor(id)))+ facet_grid(theta~., scales="free")+ geom_point(size=.1)
print(hairy_trace_plot)

## ------------------------------------------------------------------------
# We can use samples from different runs:
# I decided that half of it is the warm-up:
posteriors<- subset(longer_chains_runs,iter > iterations/2)
head(posteriors)

## ---- jointposterior, message=F, echo=F, fig.cap= 'Joint posterior of the parameters.\\label{fig:jointposterior}'----
# We'll need to do a bit of data manipulation
library(dplyr)
library(tidyr)
j_post <- spread(posteriors, theta, value)

jplot <- ggplot(j_post, aes(x=mu,y=sigma))+ geom_point(alpha=.1, color="black") + 
stat_density2d() +
        scale_fill_gradientn(colours = terrain.colors(9)) + geom_point(x=true_mu,y=true_sigma,alpha=1,color="red",shape=2) + coord_cartesian(xlim = c(380, 430),ylim=c(100, 140))  
print(jplot)

## ---- recovery-----------------------------------------------------------

plot <- ggplot(posteriors,aes(value))+ facet_grid(~theta, scales="free") +
        geom_histogram(bins=30, alpha=.5, fill="red") + 
        geom_vline(data= data.frame(theta=c("mu","sigma"),value=c(true_mu,true_sigma)), aes(xintercept=value))
print(plot)


## ---- echo=F-------------------------------------------------------------
options(scipen=999, digits=3)


## ---- recovery2----------------------------------------------------------
quantile(subset(posteriors, theta=="mu")$value, c(.0275,.975))

quantile(subset(posteriors, theta=="sigma")$value, c(.0275,.975))


## ---- echo=F-------------------------------------------------------------
options(scipen=999, digits=2)


## ---- means_theta--------------------------------------------------------

# Means of the posterior of mu and sigma:
(mean_mu <- mean(subset(posteriors,theta=="mu")$value))
(mean_sigma <- mean(subset(posteriors,theta=="sigma")$value))

## ---- over---------------------------------------------------------------
# P(mu>420) Proportion of samples over 420, or probability according to my model
# that the true mean is over 420 ms. 
mean(subset(posteriors,theta=="mu")$value>420)

## ---- visLoglik, eval = FALSE--------------------------------------------
## library(ggplot2)
## library(scales)
## 
## # These are the likelihoods for the different mu that we are going to show.
## # A good (or decent) model shouldn't give any likelihood to values of mu < 0 because reaction times can't be negative.
## mus <- seq(-1000,1000,1)
## sigmas <- seq(1,250,1)
## 
## # Data frame with the combination:
## possible_thetas <- data.frame(mu = rep(mus, each = length(sigmas)),
##                             sigma = rep(sigmas, times =length(mus)))
## 
## # I apply the likelihood(realdata, poss_values) over the rows (MARGIN=1) of
## #  possible_thetas[c("mu", "sigma")], see ?apply.
## # The following  line takes some time:
## possible_thetas$loglik <- apply(possible_thetas[c("mu", "sigma")], 1,
##                     function(poss_values) {
##                       return(loglikelihood(theta=poss_values, Y=RT))
##                       })
## 
## #Notice that the log(likelihoods) can be quite large in absolute value (very
## #negative!), this would have produced an underflow on the raw scale because they correspond to
## #values extremely close to zero.
## q <- quantile(possible_thetas$loglik,c(0,.01,.0275,.2,.5,.8,.975,.99,1))
## 
## # We are going to use the quantiles to rescale the colors:
## vis_lik <- ggplot(possible_thetas, aes(x=mu,y=sigma,fill=loglik,z=loglik))
##  # This is the color map:
## vis_lik <- vis_lik +
##     geom_raster() +
##     stat_contour(breaks=q)
## 
##     # We need to rescale the colors and the lines,
##     #because there are too many extreme values of loglik:
## vis_lik <- vis_lik +
##     scale_fill_gradientn(colours = terrain.colors(9),
##       values = rescale(q),breaks=q,labels=round(q),guide="legend") +
##      geom_point(x=true_mu,y=true_sigma,alpha=1,color="red",shape=2,inherit.aes = F)
## 
## 
## plot(vis_lik)

## ---- visLoglikZoomed, eval = FALSE--------------------------------------
## 
## 
## mus <- seq(380, 430,1)
## sigmas <- seq(100, 140,1)
## 
## possible_thetas <- data.frame(mu = rep(mus, each = length(sigmas)),
##                             sigma = rep(sigmas, times =length(mus)))
## 
## possible_thetas$loglik <- apply(possible_thetas[c("mu", "sigma")], 1,
##                     function(poss_values) {
##                       return(loglikelihood(theta=poss_values, Y=RT))
##                       })
## 
## 
## vis_lik_zoomed <-
## ggplot(possible_thetas, aes(x=mu,y=sigma,fill=loglik,z=loglik)) +
##     geom_raster() +
##     stat_contour() +  scale_fill_gradientn(colours = terrain.colors(9))+
##      geom_point(x=true_mu,y=true_sigma,alpha=1,color="red",shape=2)+ xlim(380, 430) + ylim(100, 140)
## 
## 
## 
## plot(vis_lik_zoomed)
## 
## 

## ---- jointposterior, eval = FALSE---------------------------------------
## # We'll need to do a bit of data manipulation
## library(dplyr)
## library(tidyr)
## j_post <- spread(posteriors, theta, value)
## 
## jplot <- ggplot(j_post, aes(x=mu,y=sigma))+ geom_point(alpha=.1, color="black") +
## stat_density2d() +
##         scale_fill_gradientn(colours = terrain.colors(9)) + geom_point(x=true_mu,y=true_sigma,alpha=1,color="red",shape=2) + coord_cartesian(xlim = c(380, 430),ylim=c(100, 140))
## print(jplot)

