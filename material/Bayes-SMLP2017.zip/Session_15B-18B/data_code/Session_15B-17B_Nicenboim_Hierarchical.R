## ----setup, include=FALSE,cache=F----------------------------------------
options(scipen=999, digits=3)
library(ggplot2)
theme_set(theme_classic())
library(ggplot2)
theme_set(theme_classic())

## ----open_swetsetal------------------------------------------------------
swetsetal2008 <- read.table("data/Data_SwetsEtAl2008.csv",sep=";", header=T)
head(swetsetal2008) 

# We save this horribly long column name in another column
swetsetal2008$condition <-  swetsetal2008$`amb..1...ambiguous..2...N1.attachment..3...N2.attachment.`

# We remove the globally ambiguous sentences from our data
N1N2 <- swetsetal2008[swetsetal2008$condition != 1 ,]

#We'll save RTs at 'reflexive' in a column with a clearer name:
N1N2$RT <- N1N2$reflexive

# Subset some subjects (to decrease computation time)
N1N2 <- N1N2[N1N2$sub <= 80,]

# Total number of subjects:
length(unique(N1N2$sub))

## ---- fig.height=2,message=F---------------------------------------------
library(ggplot2)
# Let's also see how the data is distributed
quantile(N1N2$RT)
ggplot(N1N2, aes(RT))+geom_histogram()


## ------------------------------------------------------------------------
#Show times at the reflexive verb for the two conditions
# 2 is N1 attachment, 3 is N2 attachment
aggregate(RT ~ condition, data=N1N2, mean)

## ------------------------------------------------------------------------
N1N2$x <- ifelse(N1N2$condition == 2, 1, -1)


## ----Mcp_forloop_code, tidy = TRUE, comment="", echo=FALSE---------------
cat(readLines("Mcp_forloop.stan"), sep = "\n")  

## ----Mcp_code, tidy = TRUE, comment="", echo=FALSE-----------------------
cat(readLines("Mcp.stan"), sep = "\n")  

## ---- message=FALSE, warning=TRUE, results="hide"------------------------
library(rstan)
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())
# We define a list with the data, notice that the names in the list need to match with the names in the data block of the model (case included)
Swets_list <- list(RT = N1N2$RT, x= N1N2$x, N= nrow(N1N2))
# We fit the model here.
fit_Mcp <- stan(file = 'Mcp.stan', 
    data = Swets_list)            

## ------------------------------------------------------------------------
print(fit_Mcp, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma", "overall_difference"), digits=3)

## ---- fig.height=2-------------------------------------------------------
traceplot(fit_Mcp, pars=c("alpha","beta","sigma"))

## ----fit_Mcp, fig.height=2, message=F------------------------------------
library(bayesplot)
posterior_Mcp <- as.array(fit_Mcp)
mcmc_hist(posterior_Mcp, pars = c("beta", "overall_difference"))

## ------------------------------------------------------------------------
# Proportion of samples above 0 should be similar to 
# the proportion of the posterior distribution above 0.
mean(rstan::extract(fit_Mcp)$beta > 0)

## ---- echo=F-------------------------------------------------------------
# I do this because of limitations of inline r code, 
subj <- as.numeric(as.factor(N1N2$sub))
Nsubj <- length(unique(subj))   

## ----Mnp_code, tidy = TRUE, comment="", echo=FALSE-----------------------
cat(readLines("Mnp.stan"), sep = "\n") 

## ----Mnp-fit, message=F,warning=T, results="hide"------------------------
# This way I'm sure that the subjects are a sequence of numbers starting from 1 
subj <- as.numeric(as.factor(N1N2$sub))
N_subj <- length(unique(subj))   
# We add this to the previous list
Swets_list <- c(Swets_list, list(subj=subj,N_subj=N_subj))

fit_Mnp <- stan(file = 'Mnp.stan', 
    data = Swets_list)

## ---- fig.height=2, eval=F-----------------------------------------------
## print(fit_Mnp, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma"))
## traceplot(fit_Mnp, pars=c("alpha","beta","sigma"))

## ------------------------------------------------------------------------
print(fit_Mnp, probs =c(.025,.5,.975), pars=c("overall_difference","average_beta"),digits=3)

## ----fit_Mnp, fig.height=2, message=F------------------------------------
# Let's look at our generated quantities
posterior_Mnp <- as.array(fit_Mnp)
mcmc_hist(posterior_Mnp, pars = c( "average_beta", "overall_difference"))

## ------------------------------------------------------------------------
mean(rstan::extract(fit_Mnp)$average_beta>0)

## ---- fig.height=10, message=F-------------------------------------------
# We plot the 95% and 80% areas of the posterior distributions of the
#  "beta" generated quantity. Notice that we use regex_pars, this is
#  because the columns of as.array(fit_Mvi) are beta[1],
#  beta[2], etc. With regex_pars we match all the beta's.
mcmc_areas(
  posterior_Mnp, 
  regex_pars = c("beta"),
  prob = 0.8,  
  prob_outer = 0.95,  
  point_est = "mean"
) 

## ------------------------------------------------------------------------
betas <- rstan::extract(fit_Mnp)$beta
# Each column represents a participant, each row a sample:
dim(rstan::extract(fit_Mnp)$beta)
# We check for each column (participant), the proportion of samples above 0
mean(colMeans(betas)>0)

## ------------------------------------------------------------------------
# We apply for each column (2), the function quantile(x,.025)
lowerCrI <- apply(betas, 2, function(x) quantile(x,.025))
# We check the proportion of columns with lower quantiles (.025) above 0
mean(lowerCrI>0)

## ----Mvi_code, tidy = TRUE, comment="", echo=FALSE-----------------------
cat(readLines("Mvi.stan"), sep = "\n")

## ----Mvi-fit, message=F,warning=T, results="hide"------------------------
fit_Mvi <- stan(file = 'Mvi.stan', 
    data = Swets_list)

## ---- fig.height=2, eval=F-----------------------------------------------
## print(fit_Mvi, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma","tau_u"))
## traceplot(fit_Mvi, pars=c("alpha","beta","sigma","tau_u"))

## ------------------------------------------------------------------------
print(fit_Mvi, probs =c(.025,.5,.975), pars=c("beta","overall_difference"),digits=3)

## ----post_fit_Mvi, fig.height=2, message=F-------------------------------
posterior_Mvi <- as.array(fit_Mvi)

mcmc_hist(posterior_Mvi, pars = c("beta", "overall_difference"))

## ------------------------------------------------------------------------
mean(rstan::extract(fit_Mvi)$beta>0)

## ----Muvivs_code, tidy = TRUE, comment="", echo=FALSE--------------------
cat(readLines("Muvivs.stan"), sep = "\n")   

## ----Muvivs-fit, message=F,warning=T, results="hide"---------------------
fit_Muvivs <- stan(file = 'Muvivs.stan', 
    data = Swets_list)


## ---- fig.height=4-------------------------------------------------------
print(fit_Muvivs, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma","tau_u1","tau_u2"))
traceplot(fit_Muvivs, pars=c("alpha","beta","sigma","tau_u1","tau_u2"))

## ----Muvivs_reparam_code, tidy = TRUE, comment="", echo=FALSE------------
cat(readLines("Muvivs_reparam.stan"), sep = "\n") 

## ----Muvivs_reparam-fit, message=F,warning=T, results="hide"-------------
fit_Muvivs_reparam <- stan(file = 'Muvivs_reparam.stan', 
    data = Swets_list)

## ---- fig.height=4-------------------------------------------------------
print(fit_Muvivs_reparam, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma","tau_u1","tau_u2"))
traceplot(fit_Muvivs_reparam, pars=c("alpha","beta","sigma","tau_u1","tau_u2"))

## ------------------------------------------------------------------------
print(fit_Muvivs_reparam, probs =c(.025,.5,.975), pars=c("beta","overall_difference"),digits=3)

## ----post_Muvivs_reparam, fig.height=2, message=F------------------------
posterior_Muvivs <- as.array(fit_Muvivs_reparam)

mcmc_hist(posterior_Muvivs, pars = c("beta", "overall_difference"))


## ------------------------------------------------------------------------
mean(rstan::extract(fit_Muvivs_reparam)$beta>0)

## ----areas_Muvivs_reparam, message=F, fig.height=10----------------------
mcmc_areas(posterior_Muvivs, regex_pars = c("difference_by_subj"), prob = 0.8, prob_outer = 0.95, point_est = "mean"
)

## ----comparison, message=F, fig.height=11--------------------------------
# We'll need to make the plot "manually"
shrinkage <- rstan::extract(fit_Muvivs_reparam)$difference_by_subj
dim(shrinkage)
# We apply the following function by columns to get the mean, and 95% credible interval of each subject's difference in ms
(shrinkage_mean <-  apply(shrinkage,2, mean))
(shrinkage_lower <-  apply(shrinkage,2, quantile,.025))
(shrinkage_upper <-  apply(shrinkage,2, quantile,.975))
shrinkage_df <- data.frame(subj = 1:length(shrinkage_mean), mean=shrinkage_mean,lower=shrinkage_lower,upper=shrinkage_upper)
shrinkage_df$Model <- "Varying intercept and slope"

no_shrinkage <- rstan::extract(fit_Mnp)$difference_by_subj
dim(no_shrinkage)
(no_shrinkage_mean <-  apply(no_shrinkage,2, mean))
(no_shrinkage_lower <-  apply(no_shrinkage,2, quantile,.025))
(no_shrinkage_upper <-  apply(no_shrinkage,2, quantile,.975))
no_shrinkage_df <- data.frame(subj = 1:length(no_shrinkage_mean), 
                    mean=no_shrinkage_mean,lower=no_shrinkage_lower,upper=no_shrinkage_upper)

no_shrinkage_df$Model <- "No pooling"

models_df <- rbind(shrinkage_df,no_shrinkage_df)

overall_difference <- rstan::extract(fit_Muvivs_reparam)$overall_difference

plot_subj <- ggplot(models_df, aes(ymin=lower, ymax=upper,x=subj,y=mean,color=Model)) 
plot_subj <- plot_subj + geom_errorbar(position = position_dodge(1)) + geom_point(position = position_dodge(1)) 

# We'll also add the mean and 95% CrI of the overall difference to the plot:
plot_subj <- plot_subj + geom_hline(yintercept=mean(overall_difference), linetype="dotted") 
plot_subj <- plot_subj + geom_hline(yintercept=quantile(overall_difference,.025), linetype="dotted",size=.1)
plot_subj <- plot_subj + geom_hline(yintercept=quantile(overall_difference,.975), linetype="dotted",size=.1)

# Finally we make the plot prettier
plot_subj <- plot_subj + scale_x_continuous(name="Participant", breaks=1:length(shrinkage_mean)) 
plot_subj <- plot_subj + scale_y_continuous("Difference in ms") + theme(legend.position = c(.8,.7))
plot_subj <- plot_subj + coord_flip() 

plot_subj

## ------------------------------------------------------------------------
rho <- .8
#Correlation matrix
(rho_u <- matrix(c(1,rho,rho,1),ncol=2))

# Cholesky factor: (we transpose it so that it looks the same as in Stan)
(L_u <- t(chol(rho_u))) 
# We verify that we recover rho_u, %*% indicates matrix multiplication (=! element-wise multiplication) 
L_u %*% t(L_u)

## ------------------------------------------------------------------------
N_subj <- 10
(z_u1 <- rnorm(N_subj,0,1))
(z_u2 <- rnorm(N_subj,0,1))

## ------------------------------------------------------------------------
# matrix z_u
(z_u <- matrix(c(z_u1,z_u2),ncol=N_subj,byrow=T))

L_u %*% z_u

## ------------------------------------------------------------------------
tau_u1 <- .2
tau_u2 <- .01
(diag_matrix_tau <- matrix(c(tau_u1,0,0,tau_u2),ncol=2))

## ------------------------------------------------------------------------
(u <- diag_matrix_tau %*% L_u %*% z_u)

# We should find that the rows are correlated ~.8
cor(u[1,],u[2,])

# We should be able to recover the tau's as well:
sd(u[1,])
sd(u[2,])

## ----Mcvivs_reparam_code, tidy = TRUE, comment="", echo=FALSE------------
cat(readLines("Mcvivs.stan"), sep = "\n")   

## ----Mcvivs-fit, message=F,warning=T, results="hide"---------------------
fit_Mcvivs <- stan(file = 'Mcvivs.stan', 
    data = Swets_list)

## ---- fig.height=6-------------------------------------------------------
print(fit_Mcvivs, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma","tau_u","L_u"))
traceplot(fit_Mcvivs, pars=c("alpha","beta","sigma","tau_u","L_u")) 

## ------------------------------------------------------------------------
print(fit_Mcvivs, probs =c(.025,.5,.975), pars=c("overall_difference","rho_u"),digits=3)

## ----post_Mcvivs, fig.height=2, message=F--------------------------------
posterior_Mcvivs <- as.array(fit_Mcvivs)
mcmc_hist(posterior_Mcvivs, pars = c("beta", "overall_difference","rho_u[1,2]"))

## ------------------------------------------------------------------------
mean(rstan::extract(fit_Mcvivs)$beta>0)

## ---- echo=F, results="hide"---------------------------------------------

rho_mean <- round(summary(fit_Mcvivs)$summary["rho_u[1,2]","mean"],2)
rho_high <- round(summary(fit_Mcvivs)$summary["rho_u[1,2]","97.5%"],2)
rho_low <- round(summary(fit_Mcvivs)$summary["rho_u[1,2]","2.5%"],2)

## ------------------------------------------------------------------------
# We need to extract the samples in the following way, because rho is actually a matrix. When we use the function extract, the first dimension consists of the samples.  See dim(rstan::extract(fit_Mcvivs)$rho_u)
mean(rstan::extract(fit_Mcvivs)$rho_u[,1,2]>0)


## ----fake-data-----------------------------------------------------------
library(MASS)

# We decide how the data should look like.
# We'll start with fake data similar to our data
N_subj <- 70
N_obs <- 24 * N_subj
x <- rep(c(1,-1), N_obs/2)
# We create a vector similar to the one in Stan, 
#that looks like 1,1,1,...,2,2,2,2... 
# Be careful to pay attention if you're repeating using each= or times=. If you forget to add each then you will generate 1,2,3,.., N_subj, 1,2,3...
subj <- rep(1:N_subj, each=N_obs/N_subj)

# We could also completely imitate the format of our data.

# N_subj <- length(unique(N1N2$sub))

# N_obs <- length(N1N2$RT)

# x <- N1N2$x

# subj <- as.numeric(as.factor(N1N2$sub))

# These will be the TRUE values, not necessarily the mean of the posterior
alpha <- 6
beta <- .05 
sigma <- .4
tau_u <- c(0.3,.05)
rho <- .5

# This matrix is symmetric, so it won't matter, but
# be careful with how R arranges the matrix values
Cor_u <- matrix(c(1,rho,rho,1), nrow = 2)

# Variance covariance matrix for 'subj':
Sigma_u <- diag(tau_u,2,2) %*% Cor_u  %*% diag(tau_u,2,2)

# Let's create the correlated adjustments (here I'm creating a matrix of u, instead of joining two vectors):
u <- mvrnorm(n = N_subj, c(0,0), Sigma_u)

# Are they correlated as expected?
cor(u)
# Are the SDs as expected?
sd(u[,1])
sd(u[,2])

# We create a vector of the location for the log-normal distribution: 
mu <- alpha + u[subj,1] + x * (beta + u[subj,2]) 
RT <- rlnorm(N_obs, mu, sigma)

fake_data_list <- list(RT=RT,
                      N=N_obs,
                      subj=subj,
                      N_subj=N_subj,
                      x=x) 

## ----fake_Mcvivs-fit, message=F,warning=T, results="hide"----------------
fit_fake_Mcvivs <- stan(file = 'Mcvivs.stan', data = fake_data_list)
 

## ---- fig.height=4-------------------------------------------------------
print(fit_fake_Mcvivs, probs =c(.025,.5,.975), pars=c("alpha","beta","sigma","tau_u","L_u"))
traceplot(fit_fake_Mcvivs, pars=c("alpha","beta","sigma","tau_u","L_u"))

## ----post_fakeMcvivs, fig.height=6, message=F----------------------------
# I save the true values with the same names as the Stan model use
true_values <- data.frame(Parameter=c("alpha","beta","sigma","tau_u[1]","tau_u[2]","rho_u[1,2]"), value=c(alpha,beta,sigma,tau_u,rho))
posterior_fakeMcvivs <- as.array(fit_fake_Mcvivs)

# Data frame with the summary
fakeMcvivs_summary <- data.frame(summary(fit_fake_Mcvivs)$summary)
fakeMcvivs_summary$Parameter <-rownames(fakeMcvivs_summary)
# For some reason, R transforms the 2.5% and 97.5% into X2.5. and X97.5. when we transform the summary to a data frame
fakeMcvivs_summary <- fakeMcvivs_summary[c("Parameter","mean","X2.5.","X97.5.")]
fakeMcvivs_summary <- subset(fakeMcvivs_summary,Parameter %in% c("alpha","beta","sigma","tau_u[1]","tau_u[2]","rho_u[1,2]"))

# We plot the historgram
p_hist <-  mcmc_hist(posterior_fakeMcvivs, pars = c("alpha","beta","sigma","tau_u[1]","tau_u[2]","rho_u[1,2]"))

# We add the summaries (notice that columns with strange characters need to go inside ``)
p_hist <- p_hist + geom_vline(data=fakeMcvivs_summary, aes(xintercept=mean),linetype="dashed")
p_hist <- p_hist + geom_vline(data=fakeMcvivs_summary, aes(xintercept=`X2.5.`),linetype="dotted")
p_hist <- p_hist + geom_vline(data=fakeMcvivs_summary, aes(xintercept=`X97.5.`),linetype="dotted")

# We add the true values in red
p_hist <- p_hist + geom_vline(data=true_values, aes(xintercept=value),color="red")

p_hist

